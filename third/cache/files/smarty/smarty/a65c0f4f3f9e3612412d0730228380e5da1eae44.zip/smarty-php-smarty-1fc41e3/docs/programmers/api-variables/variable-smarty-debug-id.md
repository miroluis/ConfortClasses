\$smarty\_debug\_id {#variable.smarty.debug.id}
===================

The value of `$smarty_debug_id` defines the URL keyword to enable
debugging at browser level. The default value is `SMARTY_DEBUG`.

See also [debugging console](#chapter.debugging.console) section,
[`$debugging`](#variable.debugging) and
[`$debugging_ctrl`](#variable.debugging.ctrl).
